"""
https://view.ifcopenshell.org/v/CJqGJhVVVEpqFRZnNGrcvVTGQMwFrFxs
"""

import ifcopenshell
import os


def writeTxtFromTxtString(PATH, exDat): #from txt string
	with open(PATH,"w") as f:
		f.write(exDat)	
	return exDat


path = "R:\\BimESC\\00-BIM STANDARD\\PYTHON\\ifcopenshell\\NHA XUONG 27_2021.03.03 (1).ifc"

ifc_file = ifcopenshell.open(path)
products = ifc_file.by_type('IfcProduct')

res = []
ssss = ""
pathWrite = "R:\\BimESC\\00-BIM STANDARD\\PYTHON\\ifcopenshell\\test.txt"
for product in products:
    if product.is_a() == "IfcElementAssembly" and "CO".lower() in product.Tag.lower() : # IfcColumn = 2373 IfcElementAssembly = 11932 IfcGirt = 0 COlumn chinh = 137
        res.append(product)
        ssss += product.GlobalId + "\t" + product.Name + "\t" + product.Tag+ "\n"
# print (ssss)
print("Count=",len(res))

# fn = writeTxtFromTxtString(pathWrite,ssss)

# print(dir(res[0]))

col = res[0]
property_set=[]
for definition in col.IsDefinedBy:
    # To support IFC2X3, we need to filter our results.
    if definition.is_a('IfcRelDefinesByProperties'):
        # print(dir(definition))
        property_set = definition.RelatingPropertyDefinition
        # print(dir(property_set))
        print(property_set.Name) # Might return Pset_WallCommon
        print(property_set.PropertyDefinitionOf)
        for defi in property_set.PropertyDefinitionOf:
            if defi.is_a('IfcRelDefinesByProperties'):
                proSet = defi.RelatingPropertyDefinition
                print(proSet.Name)
# try:
#     for property in property_set.HasProperties:
#         if property.is_a('IfcPropertySingleValue'):
#             print(property.Name)
#             print(property.NominalValue.wrappedValue)
# except:
#     pass

#print(dir(res[0]))